// Selecciono los elementos
const inputNota = document.querySelector('#nota');
const form = document.querySelector('form');
const listaNotas = document.querySelector('#notas');

let notas = [];
// Funcion 1 - Leer los inputs y los pushea en array contactos
form.addEventListener('submit', (e) => {
    e.preventDefault();
    const nota = inputNota.value;
    const fecha = new Date().toLocaleDateString();
    notas.push({
        fecha: fecha,
        body: nota
    })

    inputNota.value = '';


    renderizarNotas(notas)
})

// Funcion 2 - Recibe un array y los renderiza las notas
const renderizarNotas = (lista) => {
    // Limpio el contenedor
    listaNotas.innerHTML = '';
    lista.forEach( (nota, index) => {
        listaNotas.innerHTML += `
        <li class="list-group-item">
            <span class="d-flex justify-content-between">
                <span>
                    <span>
                        <i class="fa-solid fa-calendar text-primary"></i>
                        <strong> ${ nota.fecha }</strong>
                    </span>
                    <br>
                    <span>
                        <i class="fa-solid fa-mobile-screen text-success"></i> ${ nota.body}
                    </span>
                </span>

                <button id="${index}" class="btn btn-danger btn-delete" type="button">
                    <i class="fa-solid fa-trash"></i>
                </button>
            </span>
        </li>`;
    });

    const btns = document.querySelectorAll('.btn-delete');
    btns.forEach( btn => {
        btn.addEventListener('click', (e) => {
            const id = e.target.id;
            deleteNota(id);
        })
    });
}

// Funcion 3 - GET al JSON local y luego llama a redendericarContactos(lista)
const getContactos = async () => {
    const path = 'api/data.json';
    
    try {
        const response = await fetch(path);
        if( response.ok == false){
            throw new Error('Error al obtener los datos');
        }

        const data = await response.json();
        
        console.log(data);
        contactos = data.data;
        renderizarContactos(contactos)
    } catch (error) {
        console.error(error)
        //alert('Error en el servidor');
        renderError(error)
    }
}

 // Funcion 4 - Elimina un Nota
const deleteNota = ( index) =>{
    console.log(index);
    // Elimino localmente
    notas.splice(index, 1);
    console.log(notas);
    // Actualización
    renderizarNotas(notas);
} 

const renderError = (msg) =>{
    listNotas.innerHTML = 
    `<div class="alert alert-warning" role="alert">
                ${msg}
    </div>`
}
//getContactos();


